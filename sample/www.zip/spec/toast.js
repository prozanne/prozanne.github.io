describe('toast', function () {
    it('should be defined as "toast" namespace.', function () {
        expect(window.toast).toBeDefined();
    });
});
