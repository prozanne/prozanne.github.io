onload = function(args) {
    //var socket = io('http://168.219.241.233:8888');
    var socket = io('http://localhost:8888');

    var isJoined = false;
    var prevPinCode = '';

    setDisconnectButton();

    socket.once('connect', function() {
        console.log('connect');
    });

    socket.once('disconnect', function(argument) {
        console.log('disconnect');
        setDisconnectButton();
    });

    socket.on('response', function(chunk) {
          console.log('response: ', chunk);
          var data = JSON.parse(chunk).rsp;
          if (data.command === 'CHANNEL_JOIN' && data.state === 'success') {
              console.log('join success');
              isJoined = true;
              setConnectButton();
              setSuccessJoin();
          }
          else if(data.command === 'CHANNEL_JOIN' && data.state === 'fail') {
              console.log('join fail');
              setDisconnectButton();
              setFailedJoin();
          }
          else if ((data.command === 'CHANNEL_EXIT' && data.state === 'success') ||
              (data.command === 'CHANNEL_DESTROY' && data.state === 'success')) {
              console.log('join exit');
              isJoined = false;
              setDisconnectButton();
          }
    });

    socket.on('logDelivery', function(chunk) {
        console.log('logDelivery: ', chunk);
        var data = JSON.parse(chunk).log;

        document.getElementById('log_info').innerHTML += data.log + '<br>';
        var logObj = document.getElementById('log_info');
         scrollDown();
    });

    document.getElementById('room_send_button').addEventListener('click', function(e) {
        console.log('click room send');
        e.preventDefault();

        var roomValue = document.getElementById('room_input').value;
        console.log(roomValue);

        if(roomValue != '') {
            socket.emit('channelExit', JSON.stringify(
            {
                'args': prevPinCode
            }));

            socket.emit('channelJoin', JSON.stringify(
            {
                'args': roomValue
            }));

            prevPinCode = roomValue;
        }
        else {
            setFailedJoin();
        }

    });

    document.getElementById('url_send_button').addEventListener('click', function(e) {
        console.log('click SEND');
        e.preventDefault();

        if(!document.getElementById('url_send_button').classList.contains('disabled')) {
            var urlValue = document.getElementById('url_input').value;
            if(urlValue != '') {
                setSuccessSendUrl();
                socket.emit('urlDelivery', urlValue);
            }
            else {
                setFailedSendUrl();
            }
        }
    });

    document.getElementById('log_clear_button').addEventListener('click', function(e) {
          console.log('click clear');
          e.preventDefault();

          document.getElementById('log_info').innerHTML = '';
    });

    document.getElementById('room_input').addEventListener('keyup', function(e) {

         e.preventDefault();

         if(e.keyCode === 13) {
             console.log('enter pin code');
             document.getElementById('room_send_button').click();
         }
    });

    document.getElementById('url_input').addEventListener('keyup', function(e) {

         e.preventDefault();

         if(e.keyCode === 13) {
             console.log('enter url');
             document.getElementById('url_send_button').click();
         }
    });

    function setConnectButton() {
        document.getElementById('connect-info').classList.add('connect-badge');
        document.getElementById('connect-info').innerHTML = 'Connect';

        document.getElementById('url_send_button').classList.remove('disabled');

        document.getElementById('connection-icon').style.display = 'block';
    }

    function setDisconnectButton() {
        document.getElementById('connect-info').classList.remove('connect-badge');
        document.getElementById('connect-info').innerHTML = 'Disconnect';

        document.getElementById('url_send_button').classList.add('disabled');

        document.getElementById('connection-icon').style.display = 'none';
    }

    function setFailedJoin() {
        document.getElementById('room_input').style.backgroundColor = '#ffb0b0';
    }

    function setSuccessJoin() {
        document.getElementById('room_input').style.backgroundColor = 'white';
    }

    function setFailedSendUrl() {
        document.getElementById('url_input').style.backgroundColor = '#ffb0b0';
    }

    function setSuccessSendUrl() {
        document.getElementById('url_input').style.backgroundColor = 'white';
    }

    function setDefaultJoin() {
    }

    function scrollDown() {
        var logArea = document.getElementById('log_info');
        logArea.scrollTop = logArea.scrollHeight;
    }
}
