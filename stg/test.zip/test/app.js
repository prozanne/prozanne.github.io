
var express = require('express'),
    app = express(),
    http = require('http').Server(app),
    io = require('socket.io')(http),
    path = require('path'),
    port = process.env.PORT || 8888,
    idgen = require('./lib/idgen'),
    _ = require('underscore')._,
    readline = require('readline');

var kpi = {
  pieUser: {
    userCount: 0,
    uniqueUserCount: 0, // 중복 ip 제거
    userList: []
  },
  streamTestToolUser: {
    userCount: 0,
    uniqueUserCount: 0, // 중복 ip 제거
    userList: []
  }
}

function addPieUser(userIp) {
  kpi.pieUser.userCount += 1;
  kpi.pieUser.userList.push(userIp);
}

function addStreamTestToolUser(userIp) {
  kpi.streamTestToolUser.userCount += 1;
  kpi.streamTestToolUser.userList.push(userIp);
}

function checkUniqueUser() {
  // 각 배열에서 중복제거 한후 count값

  var pie = kpi.pieUser;
  var streamTestTool = kpi.streamTestToolUser;

  var uniqPieUser =pie.userList.reduce(function(a,b){
    if(a.indexOf(b) < 0) a.push(b);
    return a;
  }, []);

  kpi.pieUser.uniqueUserCount = uniqPieUser.length;
  kpi.pieUser.userList = uniqPieUser;

  var uniqStreamTestToolUser = streamTestTool.userList.reduce(function(a,b){
    if(a.indexOf(b) < 0) a.push(b);
    return a;
  }, []);

  kpi.streamTestToolUser.uniqueUserCount = uniqStreamTestToolUser.length;
  kpi.streamTestToolUser.userList = uniqStreamTestToolUser;

}

function logForKpi() {
  logger.info('PIE User Count : ' + kpi.pieUser.userCount);
  logger.info('PIE Unique User Count : ' + kpi.pieUser.uniqueUserCount);
  logger.info('Unique User List : ', kpi.pieUser.userList);

  logger.info('Stream-Test-Tool User Count : ' + kpi.streamTestToolUser.userCount);
  logger.info('Stream-Test-Tool Unique User Count : ' + kpi.streamTestToolUser.uniqueUserCount);
  logger.info('Unique User List : ', kpi.streamTestToolUser.userList);
}

var gChannelList = {};
var gChannelHost = {};
var defineRoomLength = 5;

const winston = require('winston');
const fs = require('fs');
const logDir = 'log';

if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir);
}

const logFilename = path.join(__dirname, logDir, '/-logfile');
//const tsFormat = () => (new Date()).toLocaleTimeString();

var logger = new (winston.Logger)({
    transports: [
      new (winston.transports.Console)({
       colorize: true,
       level: 'info'
     }),
      new (require('winston-daily-rotate-file'))({
        level: 'info',
        filename: logFilename + '.log',
        maxSize: '20m',
        maxFiles: '14d',
        datePattern: 'yyyy-MM-dd',
        prepend: true,
      })
    ]
  });

var messageType = {
    CONNECTION: 'connection',
    DISCONNECTING: 'disconnecting',
    DISCONNECT: 'disconnect',
    RESPONSE: 'response',
    URL_DELIVERY: 'urlDelivery',
    MEDIA_DATA_DELIVERY: 'mediaDataDelivery',
    LOG_DELIVERY: 'logDelivery',
    CHANNEL_EXIT: 'channelExit',
    CHANNEL_CREATE: 'channelCreate',
    CHANNEL_JOIN: 'channelJoin'
};

var responseType = {
    CHANNEL_CREATE: 'CHANNEL_CREATE',
    CHANNEL_EXIT: 'CHANNEL_EXIT',
    CHANNEL_EXIT_ALL: 'CHANNEL_EXIT_ALL',
    CHANNEL_JOIN: 'CHANNEL_JOIN',
    CHANNEL_DESTROY: 'CHANNEL_DESTROY'
};

var responseStatus = {
    SUCCESS: 'success',
    FAIL: 'fail'
};

var disconnectionType = {
    AFTER_DISCONNECTION: 'afterDisconnection',
    BEFORE_DISCONNECTION: 'beforeDisconnection'
};

var r = readline.createInterface({
    input:process.stdin,
    output:process.stdout
});

process.on('SIGINT', function() {

  logger.info('SIGINT');
  checkUniqueUser();
  logForKpi();

  setTimeout(function () {
    process.exit(0);
  }, 1000);
});

http.listen(port, function() {
    logger.info('ready : ' + port);
});

app.use(express.static('public'));

var destoryChannel = function(_io, _channelName) {
    logger.info('destroyChannel');
    gChannelList[_channelName].leave(_channelName);
};

// // response
// data.rsp = {
//     command: 'channelCreate',
//     state: 'success', // fail
//     msg: 'channelName'
// }
// // mediaDataDelivery
// data.mediadata = {
//     url: '....'
// }
var makeMsg = function(type, param) {
    logger.info('makeMsg', param);

    var data = {};

    switch (type) {
        case messageType.RESPONSE:
            data.rsp = param;
            break;
        case messageType.MEDIA_DATA_DELIVERY:
            data.mediadata = param;
            break;
        case messageType.LOG_DELIVERY:
            data.log = param;
        default:
    }

    return JSON.stringify(data);
};

var mediator = io.on(messageType.CONNECTION, function(socket) {

    logger.info('new client contected, id = ' + socket.id);

    var _join_channel = function(channelName) {
        this.join(channelName, function() {
            logger.info('join after rooms: ', this.rooms);

            gChannelList[channelName].push(this);
            var deviceRoomId;
        }.bind(this));
    }.bind(socket);

    var _kick_all = function(channelName) {
        _.each(gChannelList[channelName], function(inner) {
            inner.leave(channelName);
        });
    }.bind(socket);

    var _check_disconnected_channel = function(discType, channelName) {
        var message;
        var roomNum;

        if(discType == disconnectionType.BEFORE_DISCONNECTION) {
            roomNum = 3;
        }
        else if(discType == disconnectionType.AFTER_DISCONNECTION) {
            roomNum = 2;
        }

        if(socket.adapter.rooms[channelName].length < roomNum) {
            message = makeMsg(messageType.RESPONSE, {
                command: responseType.CHANNEL_EXIT_ALL,
                state: responseStatus.SUCCESS,
                msg: ''
            });
            mediator.to(channelName).emit(messageType.RESPONSE, message);
        }
    }.bind(socket);

    var disconnectingRoom = '';

    socket.on(messageType.DISCONNECTING, function(){
        logger.info('disconnecting, id = ', socket.rooms);

        var message = '';

        var room = _.findKey(socket.rooms, function(value)
        {
            return value.length === defineRoomLength;
        });

        if (!_.isUndefined(room))
        {
            _check_disconnected_channel(disconnectionType.BEFORE_DISCONNECTION, room);
        }
    });

    socket.on(messageType.DISCONNECT, function() {
        logger.info('disconnect, id = ' + socket.id);

        if(gChannelHost[socket.id]) {
            var channel = gChannelHost[socket.id];
            logger.info('disconnect after rooms: ', socket.rooms);
            var reply = makeMsg(messageType.RESPONSE, {
                command: responseType.CHANNEL_DESTROY,
                state: responseStatus.SUCCESS,
                msg: channel
            });
            mediator.to(channel).emit(messageType.RESPONSE, reply);

            logger.info(reply);

            _kick_all(channel);
            gChannelList[channel] = undefined;
            logger.info('host is disconnected');
        }
        else {
            logger.info('guest is disconnected');
        }
    });

    socket.on(messageType.CHANNEL_EXIT, function(chunk)
    {
        logger.info('channelExit');
        // var channelName = data.ip + '&' + data.service;
        var data = JSON.parse(chunk);
        var channelName = data.args;
        var message = '';

        if (gChannelList[channelName])
        {
            socket.leave(channelName);
            message = makeMsg(messageType.RESPONSE, {
                command: responseType.CHANNEL_EXIT,
                state: responseStatus.SUCCESS,
                msg: ''
            });

            _check_disconnected_channel(disconnectionType.AFTER_DISCONNECTION, channelName);
        }
        else
        {
            message = makeMsg(messageType.RESPONSE, {
                command: responseType.CHANNEL_EXIT,
                state: responseStatus.FAIL,
                msg: ''
            });
        }
        //socket.emit(messageType.RESPONSE, message);
    });

    socket.on(messageType.CHANNEL_CREATE, function(chunk) {
        logger.info('channelCreate: ', chunk);

        var address = socket.request.connection.remoteAddress;
        logger.info('create channel, ip = ', address);
        var obj = {};
        var channelName = idgen(defineRoomLength);
        obj[channelName] = [];

        var message = '';

        if(!gChannelList[channelName] && gChannelList[channelName] === undefined) {

          addPieUser(address); // for kpi

            gChannelList[channelName] = [];
            gChannelHost[socket.id] = channelName;
            _join_channel(channelName);
            message = makeMsg(messageType.RESPONSE, {
                command: responseType.CHANNEL_CREATE,
                state: responseStatus.SUCCESS,
                msg: channelName
            });
        }
        else {
            logger.info('channel already was created');

            message = makeMsg(messageType.RESPONSE, {
                command: responseType.CHANNEL_CREATE,
                state: responseStatus.FAIL,
                msg: 'channel already was created'
            });
        }

        //mediator.to(channelName).emit('response', message);
        socket.emit(messageType.RESPONSE, message);
    });

    socket.on(messageType.CHANNEL_JOIN, function(chunk) {
        logger.info('channelJoin: ', chunk);

        var address = socket.request.connection.remoteAddress;
        var data = JSON.parse(chunk);

        var channelName = data.args;
        var message = '';

        if(gChannelList[channelName]) {

          addStreamTestToolUser(address);

            _join_channel(channelName);
            message = makeMsg(messageType.RESPONSE, {
                command: responseType.CHANNEL_JOIN,
                state: responseStatus.SUCCESS,
                msg: channelName
            });

            mediator.to(channelName).emit(messageType.RESPONSE, message);
        }
        else {
            logger.info('channel was not created');
            message = makeMsg(messageType.RESPONSE, {
                command: responseType.CHANNEL_JOIN,
                state: responseStatus.FAIL,
                msg: 'channel was not created'
            });

            socket.emit(messageType.RESPONSE, message);
        }
    });

    socket.on(messageType.URL_DELIVERY, function(chunk)
    {
        logger.info('urlDelivery: ', chunk);

        var room = _.findKey(socket.rooms, function(value)
        {
            return value.length === defineRoomLength;
        });

        if (!_.isUndefined(room))
        {
            var data = makeMsg(messageType.MEDIA_DATA_DELIVERY, {
                url: chunk
            });
            mediator.to(room).emit(messageType.MEDIA_DATA_DELIVERY, data);
        }
    });

    socket.on(messageType.LOG_DELIVERY, function(chunk)
    {
        logger.info('logDelivery: ', chunk);

        var data = JSON.parse(chunk).log;
        var room = _.findKey(socket.rooms, function(value)
        {
            return value.length === defineRoomLength;
        });

        if (!_.isUndefined(room))
        {
            var data = makeMsg(messageType.LOG_DELIVERY, {
                log: data.log
            });
            mediator.to(room).emit(messageType.LOG_DELIVERY, data);
        }
    });
})
